# Event Form (opens from CRM buttons and from email)

## 1. Host the page (GitHub Pages)
- New repo, e.g. `event-form` > upload `index.html`
- Settings > Pages > Branch: main > Save
- Page URL: `https://<user>.github.io/event-form/`

## 2. Register the Zoho login (one time)
- https://api-console.zoho.in > Add Client > **Client-based Applications**
- JavaScript Domain: `https://<user>.github.io`
- Redirect URI: `https://<user>.github.io/event-form/`
- Copy the **Client ID** > paste in index.html: `CLIENT_ID:"..."` > commit
- No client secret is used or stored.

## 3. CRM buttons (Marketing Events > Buttons > Create)
- **New Event** (List view) > Open URL: `https://<user>.github.io/event-form/`
- **Open Event Form** (Detail page) > Open URL:
  `https://<user>.github.io/event-form/?id=${Marketing Events.Marketing Events Id}`

## 4. Email button (template for "Send to GTM Approval")
<a href="https://<user>.github.io/event-form/?id=${Marketing Events.Marketing Events Id}">Review event</a>

## Who sees what
- Marketing (role/profile has "marketing"): edits Marketing side, submits, sends to AV
- Record's ZH: reviews, accepts or changes values; any change = Reject with remarks
- Others (GTM): edit GTM side while new / draft

## Before first use
- Status: add "Approved"
- Zone → ZH IDs are in CFG.ZH_BY_ZONE at the top of index.html
- Test anytime without login: add `?demo` to the URL
